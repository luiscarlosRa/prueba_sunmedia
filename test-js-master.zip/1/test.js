var rgb = {
    red: "#FF0000",
    green: "#00FF00",
    blue: "#0000FF"
};

var wb = {
    white: "#FFFFFF",
    black: "#000000"
};

var colors = Object.assign(rgb, wb);

//MODIFICACION COPIADO 

// var colors = {...rgb, ...wb};

// //SOLUCION A ASSIGN
// var colors = new Object;

// let count = 0;
// for(let color in rgb) {
//     count++;
//     colors[count] = color;
// }

// for(let color_wb in wb) {
//     count++;
//     colors[count] = color_wb;
// };
