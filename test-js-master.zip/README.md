# SunMedia JS Tests

Este es el repositorio para la prueba técnica de Javascript de SunMedia. 
La prueba consta de hasta cuatro test. En cada una de las carpetas que 
separan los test encontrarás un fichero README.md que explica más detalladamente
qué es lo que se pide, así como el código asociado a la prueba. 

### Las pruebas:
- [Test 1](1)
- [Test 2](2)
- [Test 3](3)
- [Test 4](4)
- [Test 5](5)


### Lo que valoramos
- Buenas prácticas de desarollo
- Testing
- Buen conocimiento de JavaScript

### Presentación de la prueba

La prueba puede subirse a algún repositorio público al que podamos tener 
acceso desde el equipo de desarrollo de SunMedia. 
