export default class Event{
    constructor(message, type, second) {
        this.message = message;
        this.type = type;
        this.second = second;
    }
};