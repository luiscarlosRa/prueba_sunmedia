
export default class EventManager{
    run(arrayEvents) {
        console.log("RUNNING");
        arrayEvents.filter(event => {
            console.log(`At second ${event.second} : {type: ${event.type}, message: ${event.message}} `)
        });
    }
};