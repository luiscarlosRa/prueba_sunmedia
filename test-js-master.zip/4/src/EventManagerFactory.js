import EventManager from './EventManager';
import Event from './Event';

export default class EventManagerFactory{
    
    static create(events, types) {
        let arrayEvents = [];
        events.forEach(element => {
            arrayEvents.push
            (new Event(element.message, element.type, element.second));
        });
        return new EventManager().run(arrayEvents);
    }
};