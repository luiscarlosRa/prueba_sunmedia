const target = document.getElementById('sunmedia');
/**
 *
 * @param {string} src The video media file url
 * @return {HTMLVideoElement}
 */
const videoElm = createVideoElement('https://vod.addevweb.com/sunmedia/demos/v/normal.mp4');
/**
 * @param {HTMLDivElement} targetElm
 * @param {HTMLVideoElement} videoElm
 */

function createVideoElement(url) {
    let video = document.createElement('video');
    video.id = "embedVideo";
    video.src = url;
    video.muted = true;
    return video;
}

onInsertVideoWhenTargetIsVisible(target, videoElm);
function onInsertVideoWhenTargetIsVisible(target, videoElm) {
    let videoPosition = target.offsetTop - window.innerHeight;
    window.addEventListener('scroll', () => {
        if (window.pageYOffset > videoPosition) {
            target.appendChild(videoElm);
            videoElm.play();
        }
    });

    checkFinish(videoElm);
}


function checkFinish(videoElm) {
    videoElm.addEventListener('ended', function(){
        videoElm.removeChild(videoElm);
    })

}


